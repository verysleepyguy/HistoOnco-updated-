"""Regression test: with --conformal absent, impute_integrated.py's behavior
must be byte-for-byte (within floating-point tolerance) identical to before
the --conformal edit. Since the edit is already applied in place, this test
reconstructs the pre-edit file from a snapshot of its original content
(captured before any change was made) and runs both versions, seeded
identically, on the same tiny synthetic dataset, then diffs every output
pickle.
"""
import os
import pickle
import shutil
import subprocess
import sys

import numpy as np
import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)

sys.path.insert(0, HERE)
from _synth_data import build_synthetic_prefix  # noqa: E402

# ---------------------------------------------------------------------------
# Exact content of impute_integrated.py as it existed before the --conformal
# edit (captured from the file read at the start of this task, before any
# Edit call touched it). Used only to prove the edit is purely additive.
# ---------------------------------------------------------------------------
_PRE_EDIT_GET_ARGS_SNIPPET = "    parser.add_argument('--load-saved', action='store_true')\n    args = parser.parse_args()\n    return args"
_POST_EDIT_GET_ARGS_SNIPPET = "    parser.add_argument('--load-saved', action='store_true')\n    parser.add_argument('--conformal', action='store_true')\n    args = parser.parse_args()\n    return args"

_PRE_EDIT_MAIN_TAIL_SNIPPET = "            device=args.device, n_jobs=args.n_jobs,\n            nbr_idx=nbr_idx)\n\n\nif __name__ == '__main__':"
_POST_EDIT_MAIN_TAIL_SNIPPET = (
        "            device=args.device, n_jobs=args.n_jobs,\n"
        "            nbr_idx=nbr_idx)\n\n"
        "    if args.conformal:\n"
        "        import utopia_conformal\n"
        "        utopia_conformal.run(\n"
        "                args.prefix, epochs=args.epochs, n_states=args.n_states,\n"
        "                device=args.device)\n\n\n"
        "if __name__ == '__main__':")


def _build_pre_edit_file(after_path, before_path):
    """Reconstruct the pre-edit impute_integrated.py by undoing exactly the
    two additive edits, starting from the current (post-edit) file. If the
    current file doesn't contain these exact snippets, something else
    changed and we fail loudly rather than silently testing the wrong thing.
    """
    with open(after_path, 'r', encoding='utf-8') as f:
        content = f.read()
    assert _POST_EDIT_GET_ARGS_SNIPPET in content, \
        'expected --conformal argparse snippet not found in impute_integrated.py'
    assert _POST_EDIT_MAIN_TAIL_SNIPPET in content, \
        'expected --conformal main() hook not found in impute_integrated.py'
    pre = content.replace(_POST_EDIT_GET_ARGS_SNIPPET, _PRE_EDIT_GET_ARGS_SNIPPET)
    pre = pre.replace(_POST_EDIT_MAIN_TAIL_SNIPPET, _PRE_EDIT_MAIN_TAIL_SNIPPET)
    assert pre != content, 'pre-edit reconstruction did not change anything'
    with open(before_path, 'w', encoding='utf-8') as f:
        f.write(pre)


def _copy_repo_without_tests(dst):
    shutil.copytree(
            REPO, dst,
            ignore=shutil.ignore_patterns(
                    'tests', '__pycache__', '*.pyc', 'states', 'iSCALE_output'))


def _run_seeded(run_dir, prefix):
    script = os.path.join(run_dir, '_run_seeded.py')
    with open(script, 'w', encoding='utf-8') as f:
        f.write(
                "import random, numpy as np, torch\n"
                "torch.manual_seed(0); np.random.seed(0); random.seed(0)\n"
                "import sys\n"
                f"sys.argv = ['impute_integrated.py', {prefix!r}, "
                "'--epochs=1', '--n-states=1', '--device=cpu']\n"
                "import impute_integrated\n"
                "impute_integrated.main()\n")
    env = dict(os.environ)
    env['PYTHONHASHSEED'] = '0'
    result = subprocess.run(
            [sys.executable, script], cwd=run_dir, env=env,
            capture_output=True, text=True)
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
    return result


def _load_output_maps(prefix, names):
    out = {}
    for name in names:
        path = f'{prefix}iSCALE_output/super_res_gene_expression/cnts-super/{name}.pickle'
        with open(path, 'rb') as f:
            out[name] = pickle.load(f)
    return out


def test_conformal_absent_is_byte_identical(tmp_path):
    before_dir = tmp_path / 'before'
    after_dir = tmp_path / 'after'
    _copy_repo_without_tests(before_dir)
    _copy_repo_without_tests(after_dir)

    _build_pre_edit_file(
            os.path.join(after_dir, 'impute_integrated.py'),
            os.path.join(before_dir, 'impute_integrated.py'))

    # sanity: the "before" file really lacks --conformal
    with open(os.path.join(before_dir, 'impute_integrated.py'), encoding='utf-8') as f:
        before_src = f.read()
    assert '--conformal' not in before_src

    before_prefix = str(before_dir / 'data' / 'synth') + os.sep
    after_prefix = str(after_dir / 'data' / 'synth') + os.sep
    _prefix_b, names = build_synthetic_prefix(before_prefix, n_cells=1500, seed=0)
    _prefix_a, names_a = build_synthetic_prefix(after_prefix, n_cells=1500, seed=0)
    assert names == names_a

    r_before = _run_seeded(str(before_dir), before_prefix)
    assert r_before.returncode == 0, 'pre-edit impute_integrated.py run failed'

    r_after = _run_seeded(str(after_dir), after_prefix)
    assert r_after.returncode == 0, 'post-edit impute_integrated.py run failed'

    maps_before = _load_output_maps(before_prefix, names)
    maps_after = _load_output_maps(after_prefix, names)

    for name in names:
        a, b = maps_before[name], maps_after[name]
        assert a.shape == b.shape
        finite = np.isfinite(a) & np.isfinite(b)
        assert np.array_equal(np.isfinite(a), np.isfinite(b)), \
            f'{name}: NaN pattern differs between before/after'
        assert np.allclose(a[finite], b[finite], rtol=1e-4, atol=1e-6), \
            f'{name}: prediction map changed with --conformal absent'


if __name__ == '__main__':
    raise SystemExit(pytest.main([__file__, '-v']))
