"""Shared synthetic single-cell-mode dataset builder for the test suite.

Builds, under a given prefix directory, everything get_data_cells() /
impute_integrated.py need: embeddings-hist.pickle, he.tiff, and a
ucell_pathway_scores.csv label table, with cell x/y already converted to
he.tiff pixel space (as histoonco_pipeline.py would leave them).
"""
import os

import numpy as np
import pandas as pd
import tifffile


def build_synthetic_prefix(
        prefix, n_cells=2000, H=30, W=36, c_cls=4, c_sub=4, n_pathways=6,
        factor=4, seed=0, planted_signal=True, signal_scale=0.8, noise_scale=0.3):
    """Writes a synthetic dataset to `prefix` (must end in a path separator).

    Returns (prefix, names) where `names` are the UCell_ pathway column
    names actually written.
    """
    os.makedirs(prefix, exist_ok=True)
    rng = np.random.default_rng(seed)

    def smooth_field(n_channels, coarse=6):
        """Spatially-coherent random features: real histology features vary
        smoothly over a tissue region (unlike i.i.d.-per-pixel noise), and a
        model needs that smoothness to generalize from very few training
        epochs on a handful of cells per fold. Generate at a coarse
        resolution and upsample by nearest-neighbor + light blending."""
        coarse_h = max(2, H // coarse)
        coarse_w = max(2, W // coarse)
        field = rng.normal(size=(n_channels, coarse_h, coarse_w)).astype(np.float32)
        ys = (np.linspace(0, coarse_h - 1, H)).astype(int)
        xs = (np.linspace(0, coarse_w - 1, W)).astype(int)
        up = field[:, ys][:, :, xs]
        up += rng.normal(scale=0.1, size=up.shape).astype(np.float32)
        return up

    # ---- histology features: cls (c_cls, H, W), sub (c_sub, H, W), rgb (3, H, W) ----
    cls = smooth_field(c_cls)
    sub = smooth_field(c_sub)
    rgb = (smooth_field(3) - smooth_field(3).min()) / 4 + 0.5
    rgb = np.clip(rgb, 0, 1).astype(np.float32)
    embs_dict = dict(cls=cls, sub=sub, rgb=rgb)
    with open(f'{prefix}embeddings-hist.pickle', 'wb') as f:
        import pickle
        pickle.dump(embs_dict, f)

    # ---- he.tiff: factor x the embedding grid in each dimension ----
    he_shape = (H * factor, W * factor)
    he_img = rng.integers(0, 255, size=(*he_shape, 3), dtype=np.uint8)
    tifffile.imwrite(f'{prefix}he.tiff', he_img)

    # ---- per-cell labels: random grid cell (with margin), he.tiff pixel x/y ----
    margin = 1
    rows = rng.integers(margin, H - margin, size=n_cells)
    cols = rng.integers(margin, W - margin, size=n_cells)
    # jitter within the he.tiff pixel block that maps back to this grid cell,
    # so repeated cells landing on the same grid pixel is possible (as in
    # the real data, ~N cells per pixel), and x/y round-trips through the
    # same //factor rescale get_data_cells() applies.
    jitter_r = rng.uniform(0, factor, size=n_cells)
    jitter_c = rng.uniform(0, factor, size=n_cells)
    y_px = rows * factor + jitter_r   # he.tiff row -> y
    x_px = cols * factor + jitter_c   # he.tiff col -> x

    embs_flat = np.concatenate([cls, sub, rgb], axis=0).transpose(1, 2, 0)  # (H, W, C)
    cell_feat = embs_flat[rows, cols]  # (n_cells, C)

    names = [f'UCell_pathway{i}' for i in range(n_pathways)]
    if planted_signal:
        # plant a relationship between features and labels so the synthetic
        # end-to-end test has something learnable in very few epochs; UCell
        # scores are bounded in [0, 1]. Only a handful of feature dimensions
        # carry signal (like a few real histology axes would), scaled up so
        # a barely-trained model can pick it up before cross-fold batch
        # effects (different random inits) would otherwise dominate.
        n_signal_dims = min(5, cell_feat.shape[1])
        w = np.zeros((cell_feat.shape[1], n_pathways))
        w[:n_signal_dims] = rng.normal(size=(n_signal_dims, n_pathways)) * signal_scale
        raw = cell_feat @ w
        raw += rng.normal(scale=noise_scale, size=raw.shape)
        labels = 1.0 / (1.0 + np.exp(-raw))
    else:
        labels = rng.uniform(0, 1, size=(n_cells, n_pathways))

    df = pd.DataFrame({
            'cell_id': [f'cell_{i}' for i in range(n_cells)],
            'x': x_px, 'y': y_px,
            'log_total_counts': np.log(rng.integers(10, 500, size=n_cells).astype(float)),
    })
    for j, name in enumerate(names):
        df[name] = labels[:, j].astype(np.float32)

    df.to_csv(f'{prefix}ucell_pathway_scores.csv', index=False, float_format='%.5f')
    return prefix, names
