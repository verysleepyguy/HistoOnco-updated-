"""Unit tests for utopia_conformal's p-value / BH / confidence math:
brute-force checks, and cross-checks against UTOPIA's own implementation
(imported here only, per the "prefer reimplementing" instruction - this is
the one place UTOPIA code is imported, purely to verify our reimplementation
agrees with it).
"""
import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import utopia_conformal as uc  # noqa: E402

UTOPIA_SRC = os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        'UTOPIA')


def _import_utopia():
    sys.path.insert(0, UTOPIA_SRC)
    from UTOPIA.inference import conformal as utopia_conformal_mod
    from UTOPIA.inference import confidence as utopia_confidence_mod
    return utopia_conformal_mod, utopia_confidence_mod


def test_bh_adjust_matches_brute_force():
    rng = np.random.default_rng(0)
    pvals = rng.uniform(0, 1, size=200)

    got = uc.bh_adjust(pvals)

    # brute-force BH: for each i, max over all j<=rank(i) of m*p_(j)/j,
    # i.e. recompute directly from the definition (not vectorized).
    m = len(pvals)
    order = np.argsort(pvals)
    ranks = np.empty(m, dtype=int)
    ranks[order] = np.arange(1, m + 1)
    sorted_p = pvals[order]
    raw = m * sorted_p / np.arange(1, m + 1)
    expected_sorted = np.minimum.accumulate(raw[::-1])[::-1]
    expected_sorted = np.clip(expected_sorted, 0, 1)
    expected = np.empty(m)
    expected[order] = expected_sorted

    assert np.allclose(got, expected)
    # monotonicity: BH-adjusted p-values are non-decreasing in sorted p-value order
    assert np.all(np.diff(got[order]) >= -1e-12)


def test_compute_pvals_matches_brute_force():
    rng = np.random.default_rng(1)
    calib = rng.normal(size=500)
    test = rng.normal(size=50)
    tolerance = 0.0

    got = uc.compute_pvals(test, calib, tolerance)

    n = len(calib)
    expected = np.array([
            (1 + np.sum((calib + tolerance) < t)) / (n + 1)
            for t in test])
    assert np.allclose(got, expected)


def test_pvals_to_confidence_bounds_and_monotonic():
    pvals = np.array([0.5, 0.3, 0.1, 0.01, 0.001, 1.0])
    conf = uc.pvals_to_confidence(pvals)
    assert np.all(conf >= 0) and np.all(conf <= 1)
    # confidence must be non-increasing as p-value increases
    order = np.argsort(pvals)
    assert np.all(np.diff(conf[order]) <= 1e-12)
    assert conf[pvals == 0.5] == pytest.approx(0.0, abs=1e-9)


def test_nonconformity_score_clip():
    y = np.array([0.1, 0.4, 0.9, 0.2])
    yhat = np.array([0.2, 0.45, 0.8, 0.3])
    c = 0.4
    scores = uc.nonconformity_score_clip(y, yhat, c)
    # null points (y <= c): score = -yhat
    assert scores[0] == -0.2
    assert scores[3] == -0.3
    assert scores[1] == -0.45  # y == c counts as null (y <= c)
    # non-null point: +inf
    assert np.isinf(scores[2])


@pytest.mark.skipif(
        not os.path.isdir(UTOPIA_SRC), reason='UTOPIA reference repo not present')
def test_matches_utopia_compute_pvals_and_bh():
    utopia_conformal_mod, utopia_confidence_mod = _import_utopia()
    rng = np.random.default_rng(2)
    calib = rng.normal(size=300)
    test = rng.normal(size=40)

    ours_pvals = uc.compute_pvals(test, calib, tolerance=0.0)
    theirs_pvals = utopia_conformal_mod.compute_pvals(test, calib, tolerance=0)
    assert np.allclose(ours_pvals, theirs_pvals)

    ours_bh = uc.bh_adjust(ours_pvals)
    theirs_bh = utopia_conformal_mod.bh_adjust(theirs_pvals)
    assert np.allclose(ours_bh, theirs_bh)


@pytest.mark.skipif(
        not os.path.isdir(UTOPIA_SRC), reason='UTOPIA reference repo not present')
def test_matches_utopia_confidence_conversion():
    utopia_conformal_mod, utopia_confidence_mod = _import_utopia()
    pvals = np.array([1.0, 0.5, 0.3, 0.1, 0.05, 0.01, 0.001])
    ours = uc.pvals_to_confidence(pvals)
    theirs = utopia_confidence_mod.convert_pvals_to_confidence_scores(pvals)
    assert np.allclose(ours, theirs, atol=1e-6)


@pytest.mark.skipif(
        not os.path.isdir(UTOPIA_SRC), reason='UTOPIA reference repo not present')
def test_matches_utopia_nonconformity_and_conformal_pvals_without_tolerance():
    utopia_conformal_mod, _ = _import_utopia()
    rng = np.random.default_rng(3)
    n_calib, n_test = 400, 50
    calib_y = rng.uniform(0, 1, n_calib)
    calib_yhat = calib_y + rng.normal(0, 0.05, n_calib)
    test_yhat = rng.uniform(0, 1, n_test)
    null = 0.6

    ours_scores_calib = uc.nonconformity_score_clip(calib_y, calib_yhat, null)
    theirs_scores_calib = utopia_conformal_mod.nonconformity_score_clip(calib_y, calib_yhat, null)
    assert np.allclose(ours_scores_calib, theirs_scores_calib, equal_nan=True)

    ours_test_scores = uc.nonconformity_score_clip(np.full(n_test, null), test_yhat, null)
    theirs_test_scores = utopia_conformal_mod.nonconformity_score_clip(
            null * np.ones(n_test), test_yhat, null)
    assert np.allclose(ours_test_scores, theirs_test_scores, equal_nan=True)

    ours_pvals = uc.bh_adjust(uc.compute_pvals(ours_test_scores, ours_scores_calib, 0.0))
    theirs_pvals = utopia_conformal_mod.conformal_pvals(
            calib_y, calib_yhat, test_yhat, null, tolerance=0)
    assert np.allclose(ours_pvals, theirs_pvals)


if __name__ == '__main__':
    raise SystemExit(pytest.main([__file__, '-v']))
